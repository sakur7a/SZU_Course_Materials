提交包结构说明

code/    核心源码、计时库、编译脚本和绘图脚本
results/ Windows 原生环境下重新测得的数据、图片和实验报告

未包含内容：编译生成的 .exe、Linux/WSL 可执行文件、__pycache__ 等中间产物。
